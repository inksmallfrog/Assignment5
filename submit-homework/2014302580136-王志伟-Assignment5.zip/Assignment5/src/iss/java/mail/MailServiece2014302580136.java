package iss.java.mail;

import javax.mail.*;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

/**
 * Created by inksmallfrog on 11/14/15.
 */
public class MailServiece2014302580136 implements IMailService{

    private Session session = null;
    private final String smtpServer = "smtp.163.com";
    private final String imapServer = "pop3.163.com";
    private Message sentMessage;
    private Date sentDate = null;

    @Override
    public void connect() throws MessagingException {
        Properties properties = System.getProperties();
        properties.put("mail.smtp.auth", true);
        properties.put("mail.store.protocol", "pop3");
        properties.put("mail.smtp.host", smtpServer);
        properties.put("mail.pop3.host", imapServer);

        Authenticator myEmailAuthenticator = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("inksmallfrog@163.com", "3345*moxiaowa");
            }
        };

        session = Session.getInstance(properties, myEmailAuthenticator);
    }

    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException {
        sentMessage = new MimeMessage(session);
        sentMessage.setFrom(new InternetAddress("inksmallfrog@163.com"));
        sentMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        sentMessage.setSubject(subject);
        sentMessage.setContent(content, "text/html;charset=utf-8");
        sentDate = new Date();
        Transport.send(sentMessage);
    }

    @Override
    public boolean listen() throws MessagingException {
        Store store = session.getStore();
        store.connect();
        Folder myFolder = store.getFolder("Inbox");
        myFolder.open(Folder.READ_ONLY);
        Message[] messages = myFolder.getMessages();
        for(Message message : messages){
            String date = message.getHeader("date")[0];
            Date receiveDate = new Date(date);

            if(sentDate.before(receiveDate)){
                myFolder.close(false);
                return true;
            }
        }
        myFolder.close(false);
        return false;
    }

    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        Store store = session.getStore();
        store.connect();
        Folder myFolder = store.getFolder("Inbox");
        myFolder.open(Folder.READ_ONLY);
        Message[] messages = myFolder.getMessages();
        for(Message message : messages){
            String date = message.getHeader("date")[0];
            Date receiveDate = new Date(date);
            if (sentDate.after(receiveDate)){
                continue;
            }
            if(subject.equals(message.getSubject())){
                String content = message.getContent().toString();
                myFolder.close(false);
                return content;
            }
        }
        myFolder.close(false);
        return null;
    }
}
